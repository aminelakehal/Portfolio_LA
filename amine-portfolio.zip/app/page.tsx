"use client"

import AmineLakehalPortfolio from "../portfolio"

export default function SyntheticV0PageForDeployment() {
  return <AmineLakehalPortfolio />
}